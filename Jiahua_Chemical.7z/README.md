# 嘉华化工厂

`node_modules/vant/lib/tabs/index.js`
311 `}), this.slots('nav-right')])]);`