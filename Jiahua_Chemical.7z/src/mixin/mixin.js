export const mixin = {
  methods: {
    pageBack() {
      this.$router.back();
    }
  }
};
