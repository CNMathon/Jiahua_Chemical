/**
 * 接口域名的管理
 */
const base = {
  sq: "http://47.96.148.87:8980/js/a/"
  // bd: "http://dktoo.com/api"
};

export default base;
