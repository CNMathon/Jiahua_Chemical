<template>
  <div class="home">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "page4_home"
};
</script>
