<template>
  <div class="home">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "page_1-home"
};
</script>
