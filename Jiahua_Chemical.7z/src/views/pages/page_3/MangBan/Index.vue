<template>
  <div class="mangban">
    <van-nav-bar
      title="盲板抽堵安全"
      left-text="返回"
      right-text="操作"
      left-arrow
      @click-left="pageBack"
      @click-right="openAction"
    />
    <!-- 申请部门 -->
    <cell-value title="申请部门" required :value="sendData.applyData" class="readonly"></cell-value>
    <!-- 申请人 -->
    <cell-value title="申请人" required :value="sendData.applyer" class="readonly"></cell-value>

    <div class="cell_group" v-for="(item, index) in sendData.pipe" :key="index">
      <!-- 管道序号 -->
      <cell-value :title="'管道' + (index + 1)" class="guandao-id"></cell-value>
      <!-- 设备管道名称 -->
      <div class="cell">
        <div class="cell_title">
          <span>设备管道名称</span>
        </div>
        <div class="cell_input">
          <input type="text" placeholder="手工录入" v-model="item.pipeName" />
        </div>
      </div>
      <!-- 介质 -->
      <div class="cell">
        <div class="cell_title">
          <span>介质</span>
        </div>
        <div class="cell_input">
          <input type="text" placeholder="手工录入" v-model="item.pipeMedium" />
        </div>
      </div>
      <!-- 温度 -->
      <div class="cell">
        <div class="cell_title">
          <span>温度</span>
        </div>
        <div class="cell_input">
          <input type="text" placeholder="手工录入" v-model="item.pipeTemp" />
        </div>
      </div>
      <!-- 压力 -->
      <div class="cell">
        <div class="cell_title">
          <span>压力</span>
        </div>
        <div class="cell_input">
          <input type="text" placeholder="手工录入" v-model="item.pipePressure" />
        </div>
      </div>
      <!-- 材质 -->
      <div class="cell">
        <div class="cell_title">
          <span>材质</span>
        </div>
        <div class="cell_value" @click="materialShowShow = true">
          <span>{{ item.pipeMaterial || "点击选择" }}</span>
          <span class="cell_value_arrow">
            <van-icon name="arrow" />
          </span>
        </div>
      </div>
      <!-- 规格 -->
      <div class="cell">
        <div class="cell_title">
          <span>规格</span>
        </div>
        <div class="cell_input">
          <input type="text" placeholder="手工录入" v-model="item.pipeSpec" />
        </div>
      </div>
      <!-- 编号 -->
      <div class="cell">
        <div class="cell_title">
          <span>编号</span>
        </div>
        <div class="cell_input">
          <input type="text" placeholder="手工录入" v-model="item.pipeNumber" />
        </div>
      </div>

      <!-- 选择Popup -->
      <div class="popup-group">
        <!-- 材质选择 -->
        <van-popup v-model="materialShowShow" position="bottom">
          <van-picker
            show-toolbar
            title="材质选择"
            :columns="materialColumns"
            @cancel="onMaterialCancel"
            @confirm="onMaterialConfirm"
          />
        </van-popup>
      </div>

      <!-- 堵时间 -->
      <cell-time v-model="item.pipePullTime" title="堵时间"></cell-time>
      <!-- 抽时间 -->
      <cell-time v-model="item.pipeBlockTime" title="抽时间"></cell-time>
      <!-- 堵作业人 -->
      <cell-select-user
        title="堵作业人"
        :storeModule="storeModule"
        :storeKey="'pipeBlockOperator' + index"
        v-model="item.pipeBlockOperator"
      ></cell-select-user>
      <!-- 抽作业人 -->
      <cell-select-user
        title="抽作业人"
        :storeModule="storeModule"
        :storeKey="'pipePullOperator' + index"
        v-model="item.pipePullOperator"
      ></cell-select-user>
      <!-- 堵监护人 -->
      <cell-select-user
        title="堵监护人"
        :storeModule="storeModule"
        :storeKey="'pipeBlockGuardian' + index"
        v-model="item.pipeBlockGuardian"
      ></cell-select-user>
      <!-- 抽监护人 -->
      <cell-select-user
        title="抽监护人"
        :storeModule="storeModule"
        :storeKey="'pipePullGuardian' + index"
        v-model="item.pipePullGuardian"
      ></cell-select-user>
      <div class="add_device">
        <!-- <div class="swiper">
          <span class="swiper_item swiper_item_select"></span>
          <span class="swiper_item"></span>
        </div>-->
        <div class="add_device_action" @click="addDevice">
          <van-icon name="add-o" color="#6096F8" />
        </div>
      </div>
    </div>
    <!-- 第二部分 -->
    <div class="cell_group">
      <!-- 生产部门作业负责人 -->
      <cell-select-user
        title="生产部门作业负责人"
        required
        :storeModule="storeModule"
        storeKey="dhzyPrincipal"
        v-model="sendData.scMan"
      ></cell-select-user>
      <!-- 作业部门负责人 -->
      <div class="cell">
        <div class="cell_title">
          <span>作业部门负责人</span>
          <span class="required">*</span>
        </div>
        <div class="cell_value">
          <span>人名</span>
          <span class="cell_value_arrow">
            <van-icon name="search" />
          </span>
        </div>
      </div>
      <!-- 涉及其他特殊作业 -->
      <cell-select-tag
        required
        title="涉及其他特殊作业"
        storeKey="otherSpecial"
        :tagList="otherSpecial"
        :showList="list_1"
        :storeModule="storeModule"
      ></cell-select-tag>
    </div>

    <!-- 安全措施 -->
    <div class="confirm">
      <div class="head">
        <div class="head_1">安全措施</div>
        <div class="head_2">确认</div>
        <div class="head_3">确认人</div>
      </div>
      <div class="confirm_list">
        <Signature
          :checked="checked[0] ? checked[0].checked : false"
          :img="checked[0] ? checked[0].img : ''"
          @checked="showSignature(0)"
          @cancel="signatureCancel(0)"
        >
          <span slot>对进入受限空间危险性进行分析。</span>
        </Signature>
        <Signature
          :checked="checked[1] ? checked[1].checked : false"
          :img="checked[1] ? checked[1].img : ''"
          @checked="showSignature(1)"
          @cancel="signatureCancel(1)"
        >
          <span slot>与受限空间有联系的阀门管线加盲板隔离，列出盲板清单，落实抽堵盲板责任人。</span>
        </Signature>
        <Signature
          :checked="checked[2] ? checked[2].checked : false"
          :img="checked[2] ? checked[2].img : ''"
          @checked="showSignature(2)"
          @cancel="signatureCancel(2)"
        >
          <div slot>设备经过置换、吹扫、蒸煮。</div>
        </Signature>
        <Signature
          :checked="checked[3] ? checked[3].checked : false"
          :img="checked[3] ? checked[3].img : ''"
          @checked="showSignature(3)"
          @cancel="signatureCancel(3)"
        >
          <div slot>设备打开通风孔进行自然通风,温度适宜人员作业;必要时采用强制通风或佩戴空气呼吸器,但严禁用通氧气或富氧空气的方法补充氧。</div>
        </Signature>
        <Signature
          :checked="checked[4] ? checked[4].checked : false"
          :img="checked[4] ? checked[4].img : ''"
          @checked="showSignature(4)"
          @cancel="signatureCancel(4)"
        >
          <div slot>相关设备进行处理,带搅拌机的设备要切断电源,电源开关处加锁或挂“禁止合闸”标志牌,设专人监护。</div>
        </Signature>
        <Signature
          :checked="checked[5] ? checked[5].checked : false"
          :img="checked[5] ? checked[5].img : ''"
          @checked="showSignature(5)"
          @cancel="signatureCancel(5)"
        >
          <div slot>检查受限空间内部已具备作业条件,清罐时(无需用/已采用)防爆工具。</div>
        </Signature>
        <Signature
          :checked="checked[6] ? checked[6].checked : false"
          :img="checked[6] ? checked[6].img : ''"
          @checked="showSignature(6)"
          @cancel="signatureCancel(6)"
        >
          <div slot>检查受限空间进出口通道,无阻碍人员进出的障碍物。</div>
        </Signature>
        <Signature
          :checked="checked[6] ? checked[6].checked : false"
          :img="checked[6] ? checked[6].img : ''"
          @checked="showSignature(6)"
          @cancel="signatureCancel(6)"
        >
          <div slot>分析盛装过可燃有毒液体、气体的受限空间内的可燃、有毒有害气体含量。</div>
        </Signature>
        <Signature
          :checked="checked[6] ? checked[6].checked : false"
          :img="checked[6] ? checked[6].img : ''"
          @checked="showSignature(6)"
          @cancel="signatureCancel(6)"
        >
          <div slot>作业人员清楚受限空间内存在的其他危险因素,如内部附件、集渣坑等。</div>
        </Signature>
        <Signature
          :checked="checked[6] ? checked[6].checked : false"
          :img="checked[6] ? checked[6].img : ''"
          @checked="showSignature(6)"
          @cancel="signatureCancel(6)"
        >
          <div slot>作业监护措施:消防器材</div>
          <div>
            <input type="text" />
          </div>
          <div>、救生绳</div>
          <div>
            <input type="text" />
          </div>
          <div>、气防装备</div>
          <div>
            <input type="text" />
          </div>
        </Signature>
        <Signature
          :checked="checked[6] ? checked[6].checked : false"
          :img="checked[6] ? checked[6].img : ''"
          @checked="showSignature(6)"
          @cancel="signatureCancel(6)"
        >
          <div slot>检查受限空间进出口通道,无阻碍人员进出的障碍物。</div>
        </Signature>
      </div>
    </div>

    <!-- 操作Popup -->
    <van-popup v-model="isShowAction" position="bottom" class="action">
      <button @click="postData">保存</button>
      <button>工作流提交</button>
      <button @click="closeAction">取消</button>
    </van-popup>
  </div>
</template>
<script>
import { business } from "../../../../mixin/business";
import { mapState } from "vuex";
import Canvas from "@/components/Canvas.vue";
import Signature from "../components/Signature.vue";
export default {
  name: "mangban",
  data() {
    return {
      storeModule: "mangban",
      materialShowShow: false,
      material: {
        index: 0,
        value: ""
      },
      materialColumns: ["特殊", "|类", "||类"],
      pullTimeShow: false,
      blockTimeShow: false,
      currentDate: new Date(),
      list_1: [
        "登高",
        "动火",
        "临时用电",
        "盲板抽堵",
        "吊装",
        "动土",
        "断路作业"
      ],
      checked: [],
      isShowAction: false,
      sendData: {
        applyDept: this.$userInfo.officeName, // 申请部门
        applyer: this.$userInfo.userName, // 申请人
        scMan: "", // 生产部门作业负责人
        pipe: [
          {
            pipeName: "", // 设备管道名称
            pipeMedium: "", // 介质
            pipeTemp: "", // 温度
            pipePressure: "", // 压力
            pipeMaterial: "", // 材质
            pipeSpec: "", // 规格
            pipeNumber: "", // 编号
            pipePullTime: "", // 堵时间
            pipeBlockTime: "", // 抽时间
            pipeBlockOperator: "", // 堵作业人
            pipePullOperator: "", // 抽作业人
            pipeBlockGuardian: "", // 堵监护人
            pipePullGuardian: "", // 抽监护人
            otherSpecial: [] //涉及其他特殊作业
          }
        ]
      }
    };
  },
  computed: mapState({
    otherSpecial: state => state.mangban.otherSpecial,
    pipeBlockOperator: state => state.mangban.pipeBlockOperator,
    pipePullOperator: state => state.mangban.pipePullOperator,
    pipeBlockGuardian: state => state.mangban.pipeBlockGuardian,
    pipePullGuardian: state => state.mangban.pipePullGuardian,
  }),
  components: {
    // DonghuoConfirm,
    Canvas,
    Signature
  },
  mixins: [business],
  created() {},
  methods: {
    // 打开操作Popup
    openAction() {
      this.isShowAction = true;
    },

    // 关闭操作Popup
    closeAction() {
      this.isShowAction = false;
    },

    pageBack() {
      this.$router.back();
    },

    // 材质选择
    onMaterialConfirm(value, index) {
      this.materialShowShow = false;
      this.sendData.pipe[index].pipeMaterial = value;
    },

    postData() {
      console.log(this.sendData);
    },

    // 材质选择取消
    onMaterialCancel() {
      this.materialShowShow = false;
    },
    // 取消抽时间选择
    onPullTimeCancel() {
      this.pullTimeShow = false;
    },
    // 确认抽时间选择
    onPullTimeConfirm(index, value) {
      console.log(index, value)
      this.pullTimeShow = false;
    },
    // 取消堵时间选择
    onBlockTimeCancel() {
      this.blockTimeShow = false;
    },
    // 确认堵时间选择
    onBlockTimeConfirm() {
      this.blockTimeShow = false;
    },
    toSelect(index) {
      this.$router.push({
        path: "./select",
        query: {
          index: index,
          showList: this[`list_${index}`]
        }
      });
    },
    addDevice() {
      this.$router.push({
        path: "./add_device"
      });
    }
  },
  watch: {
    otherSpecial(res) {
      this.sendData.otherSpecial = res;
    },
    pipeBlockOperator(res) {
      this.sendData.pipe[0].pipeBlockOperator = res.map((value) => {return value.userName});
    },
    pipePullOperator(res) {
      this.sendData.pipe[0].pipePullOperator = res.map((value) => {return value.userName});
    },
    pipeBlockGuardian(res) {
      this.sendData.pipe[0].pipeBlockGuardian = res.map((value) => {return value.userName});
    },
    pipePullGuardian(res) {
      this.sendData.pipe[0].pipePullGuardian = res.map((value) => {return value.userName});
    },
  }
};
</script>
<style lang="scss" scoped>
@import "@/assets/scss/cell.scss";
.mangban {
  background-color: #f5f5f5;
  .next {
    width: 100%;
    height: 98px;
    margin-top: 25px;
    font-size: 32px;
    text-align: center;
    color: rgba(255, 255, 255, 1);
    line-height: 98px;
    background: rgba(96, 150, 248, 1);
    box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.5);
  }
}

.guandao-id {
  background-color: rgb(0, 142, 225) !important;
}

.action {
  padding-left: 30px;
  padding-right: 30px;
  background-color: transparent;
  button {
    width: 100%;
    height: 110px;
    margin-bottom: 20px;
    background-color: white;
    border: none;
    border-radius: 30px;
    color: rgb(0, 118, 255);
    font-size: 35px;
  }
}
</style>
